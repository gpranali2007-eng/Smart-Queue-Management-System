package com.smartqueue.smartqueuemanagementsystem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/completeToken")
public class CompleteTokenServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        String selectSql = "SELECT id, token_number FROM tokens "
                         + "WHERE status = 'Serving' "
                         + "ORDER BY token_number ASC LIMIT 1";

        String updateSql = "UPDATE tokens SET status = 'Completed' "
                         + "WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement selectPs = con.prepareStatement(selectSql);
             ResultSet rs = selectPs.executeQuery()) {

            if (rs.next()) {

                int id = rs.getInt("id");
                int tokenNumber = rs.getInt("token_number");

                try (PreparedStatement updatePs =
                             con.prepareStatement(updateSql)) {

                    updatePs.setInt(1, id);
                    updatePs.executeUpdate();
                }

                request.setAttribute("tokenNumber", tokenNumber);

            } else {

                request.setAttribute("message", "No token is currently being served.");
            }

            request.getRequestDispatcher("completeToken.jsp")
                   .forward(request, response);

        } catch (Exception e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to complete token."
            );
        }
    }
}