package com.smartqueue.smartqueuemanagementsystem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/queueStatus")
public class QueueStatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String username = (String) session.getAttribute("username");

        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String sql = "SELECT token_number, service, status, created_at "
                   + "FROM tokens WHERE username = ? "
                   + "ORDER BY token_number DESC";

        List<Map<String, Object>> tokens = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Map<String, Object> token = new HashMap<>();

                token.put("token_number", rs.getInt("token_number"));
                token.put("service", rs.getString("service"));
                token.put("status", rs.getString("status"));
                token.put("created_at", rs.getTimestamp("created_at"));

                tokens.add(token);
            }

            request.setAttribute("tokens", tokens);

            request.getRequestDispatcher("queueStatus.jsp")
                   .forward(request, response);

        } catch (Exception e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to retrieve queue status."
            );
        }
    }
}