package com.smartqueue.smartqueuemanagementsystem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@WebServlet("/callNextToken")
public class CallNextTokenServlet extends HttpServlet {

    // Multithreading: creates a separate background thread
    private final ExecutorService executor =
            Executors.newSingleThreadExecutor();

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        String selectSql = "SELECT id, token_number FROM tokens "
                         + "WHERE status = 'Waiting' "
                         + "ORDER BY token_number ASC LIMIT 1";

        String updateSql = "UPDATE tokens SET status = 'Serving' "
                         + "WHERE id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement selectPs = con.prepareStatement(selectSql);
             ResultSet rs = selectPs.executeQuery()) {

            if (rs.next()) {

                int id = rs.getInt("id");
                int tokenNumber = rs.getInt("token_number");

                try (PreparedStatement updatePs =
                             con.prepareStatement(updateSql)) {

                    updatePs.setInt(1, id);
                    updatePs.executeUpdate();
                }

                // Multithreading: run a background task
                final int calledToken = tokenNumber;

                executor.submit(() -> {
                    System.out.println(
                        "Background thread: Token "
                        + calledToken
                        + " is now being served."
                    );
                });

                request.setAttribute("tokenNumber", tokenNumber);

            } else {

                request.setAttribute("message", "No waiting tokens.");
            }

            request.getRequestDispatcher("callNextToken.jsp")
                   .forward(request, response);

        } catch (Exception e) {

            e.printStackTrace();

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to call next token."
            );
        }
    }

    @Override
    public void destroy() {
        // Stop the background thread when the servlet is destroyed
        executor.shutdown();
        super.destroy();
    }
}