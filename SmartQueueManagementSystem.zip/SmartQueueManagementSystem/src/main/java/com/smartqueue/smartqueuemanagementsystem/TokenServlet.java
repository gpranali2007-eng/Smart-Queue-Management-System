package com.smartqueue.smartqueuemanagementsystem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/generateToken")
public class TokenServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String username = (String) session.getAttribute("username");

        if (username == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String service = request.getParameter("service");

        if (service == null || service.trim().isEmpty()) {
            service = "General Enquiry";
        }

        String getTokenSql = "SELECT MAX(token_number) AS max_token FROM tokens";

        String insertSql = "INSERT INTO tokens (token_number, username, service, status) "
                         + "VALUES (?, ?, ?, 'Waiting')";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement getTokenPs = con.prepareStatement(getTokenSql);
             ResultSet rs = getTokenPs.executeQuery()) {

            int nextToken = 1;

if (rs.next() && rs.getObject("max_token") != null) {
    nextToken = rs.getInt("max_token") + 1;
}

            try (PreparedStatement insertPs = con.prepareStatement(insertSql)) {

                insertPs.setInt(1, nextToken);
                insertPs.setString(2, username);
                insertPs.setString(3, service);

                insertPs.executeUpdate();
            }

            response.sendRedirect("tokenSuccess.jsp");

        } catch (Exception e) {

    e.printStackTrace();

    response.setContentType("text/plain");
    response.getWriter().println("TOKEN ERROR:");
    response.getWriter().println(e.toString());
}
        }
}
    
