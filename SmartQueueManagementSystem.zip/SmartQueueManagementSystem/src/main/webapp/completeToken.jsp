<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Complete Token - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Complete Current Token</h2>

    <%
        Integer tokenNumber = (Integer) request.getAttribute("tokenNumber");
        String message = (String) request.getAttribute("message");
    %>

    <% if (tokenNumber != null) { %>

        <h3>Token <%= tokenNumber %> Completed Successfully!</h3>

        <p>The current token has been marked as completed.</p>

    <% } else if (message != null) { %>

        <p><%= message %></p>

    <% } %>

    <br>

    <a href="adminDashboard.jsp">Back to Admin Dashboard</a>

</body>
</html>