<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Admin Login</h2>

    <form action="adminLogin" method="post">

        <label>Username:</label><br>
        <input type="text" name="username" required>
        <br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required>
        <br><br>

        <button type="submit">Admin Login</button>

    </form>

    <br>

    <a href="index.jsp">Back to Home</a>

</body>
</html>