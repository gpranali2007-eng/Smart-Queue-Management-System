<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>User Login - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>User Login</h2>

    <form action="login" method="post">

        <label>Username:</label><br>
        <input type="text" name="username" required>
        <br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required>
        <br><br>

        <button type="submit">Login</button>

    </form>

    <br>

    <a href="index.jsp">Back to Home</a>

</body>
</html>