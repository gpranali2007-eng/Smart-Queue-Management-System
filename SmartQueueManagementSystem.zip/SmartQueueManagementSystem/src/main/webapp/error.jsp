<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Error - Smart Queue</title>
</head>

<body>

    <h2>Something went wrong!</h2>

    <p>Sorry, an unexpected error occurred while processing your request.</p>

    <br>

    <a href="index.jsp">Back to Home</a>

</body>
</html>