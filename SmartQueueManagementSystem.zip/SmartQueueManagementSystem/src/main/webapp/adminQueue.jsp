<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Queue - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>All Queue Tokens</h2>

    <%
        List<Map<String, Object>> tokens =
                (List<Map<String, Object>>) request.getAttribute("tokens");
    %>

    <% if (tokens == null || tokens.isEmpty()) { %>

        <p>No tokens found.</p>

    <% } else { %>

        <table border="1" cellpadding="10">

            <tr>
                <th>Token Number</th>
                <th>Username</th>
                <th>Service</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>

            <% for (Map<String, Object> token : tokens) { %>

                <tr>
                    <td><%= token.get("token_number") %></td>
                    <td><%= token.get("username") %></td>
                    <td><%= token.get("service") %></td>
                    <td><%= token.get("status") %></td>
                    <td><%= token.get("created_at") %></td>
                </tr>

            <% } %>

        </table>

    <% } %>

    <br>

    <a href="adminDashboard.jsp">Back to Admin Dashboard</a>

</body>
</html>