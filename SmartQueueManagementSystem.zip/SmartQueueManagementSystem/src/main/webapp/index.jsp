<!DOCTYPE html>
<html>
<head>
    <title>Smart Queue Management System</title>
    <link rel="stylesheet" href="style.css">
</head>

<body class="home-page">

    <div class="home-card">

        <h1>Smart Queue Management System</h1>

        <p>Manage digital tokens and queues efficiently.</p>

        <div class="home-buttons">
            <a href="login.jsp" class="main-button">User Login</a>
            <a href="adminLogin.jsp" class="main-button">Admin Login</a>
        </div>

    </div>

</body>
</html>