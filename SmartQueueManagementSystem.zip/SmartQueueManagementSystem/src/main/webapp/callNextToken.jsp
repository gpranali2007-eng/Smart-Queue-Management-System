<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Call Next Token - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Call Next Token</h2>

    <%
        Integer tokenNumber = (Integer) request.getAttribute("tokenNumber");
        String message = (String) request.getAttribute("message");
    %>

    <% if (tokenNumber != null) { %>

        <h3>Now Serving Token: <%= tokenNumber %></h3>

        <p>The next waiting token has been called.</p>

    <% } else if (message != null) { %>

        <p><%= message %></p>

    <% } %>

    <br>

    <a href="adminDashboard.jsp">Back to Admin Dashboard</a>

</body>
</html>