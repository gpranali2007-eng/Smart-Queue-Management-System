<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>
<head>
    <title>Token Generated</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Token Generated Successfully!</h2>

    <p>Your token has been generated successfully.</p>
    <p>Status: Waiting</p>

    <br>

    <a href="userDashboard.jsp">Back to Dashboard</a>

</body>
</html>