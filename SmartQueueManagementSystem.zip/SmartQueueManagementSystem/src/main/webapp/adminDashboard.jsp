<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    if (session.getAttribute("admin") == null) {
        response.sendRedirect("adminLogin.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Admin Dashboard</h2>

    <p>Welcome, Admin!</p>

    <h3>Queue Management</h3>

    <form action="callNextToken" method="post">
    <button type="submit">Call Next Token</button>
</form>
    <br><br>

    <form action="completeToken" method="post">
    <button type="submit">Complete Current Token</button>
</form>
    <br><br>

    <form action="adminQueue" method="get">
    <button type="submit">View Queue</button>
</form>
    <br><br>

    <a href="logout">Logout</a>

</body>
</html>