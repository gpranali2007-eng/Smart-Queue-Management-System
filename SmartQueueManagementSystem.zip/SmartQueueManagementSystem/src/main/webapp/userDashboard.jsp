<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    if (session.getAttribute("username") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard - Smart Queue</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Welcome to Smart Queue Management System</h2>

    <p>You are logged in successfully.</p>

    <h3>Queue Services</h3>

    <form action="generateToken" method="post">

    <label>Select Service:</label>
    <select name="service">
        <option value="General Enquiry">General Enquiry</option>
        <option value="Billing">Billing</option>
        <option value="Customer Support">Customer Support</option>
    </select>

    <br><br>

    <button type="submit">Generate Token</button>

</form>
    <br><br>

  <a href="queueStatus">View Queue Status</a>
    <br><br>

    <a href="logout">Logout</a>
</body>
</html>